package com.example.middleware;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiddlewareApplicationTests {

    @Test
    void contextLoads() {
    }

}
