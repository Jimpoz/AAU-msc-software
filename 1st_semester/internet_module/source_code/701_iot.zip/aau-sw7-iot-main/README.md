# aau-sw7-iot
University project 2025 fall semester at AAU. The project is a website capable of tracking the source of information, such as the first webpage where the info appeared.
