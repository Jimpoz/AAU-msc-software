# Install guide

Go to `chrome://extensions`, click _Load unpacked_, navigate to the `browser_extension` folder and open it.

## How it works

Uses the nlp_web module directly, sends the url of the current page as input and based on the response highlights sentences and displays their origins in cards.