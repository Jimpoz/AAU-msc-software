import React from "react";
import AuthUI from "../../components/AuthUI";

export default function RegisterPage() {
  return <AuthUI initialSignIn={false} />;
}