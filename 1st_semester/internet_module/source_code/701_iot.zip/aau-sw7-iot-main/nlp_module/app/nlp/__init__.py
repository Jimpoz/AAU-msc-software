from .pipeline import NLP_Pipeline, nlp_article
from .sitecontent import get_site_data