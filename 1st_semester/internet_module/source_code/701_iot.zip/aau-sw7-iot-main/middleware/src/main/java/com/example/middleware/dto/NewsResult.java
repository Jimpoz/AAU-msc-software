package com.example.middleware.dto;

public class NewsResult extends SearchResultBase {
}
