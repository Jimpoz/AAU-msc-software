package com.example.middleware.dto;

public class WebsiteResult extends SearchResultBase {
}
